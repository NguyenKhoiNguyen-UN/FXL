const vscode = require('vscode');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const cp = require('child_process');

let diagnosticCollection;
const pendingTimers = new Map();
const runningChecks = new Map();
const latestRun = new Map();
let runCounter = 0;

function activate(context) {
  diagnosticCollection = vscode.languages.createDiagnosticCollection('fxl');
  context.subscriptions.push(diagnosticCollection);

  const check = (document) => scheduleDiagnostics(document);

  context.subscriptions.push(
    vscode.workspace.onDidOpenTextDocument(check),
    vscode.workspace.onDidSaveTextDocument(check),
    vscode.workspace.onDidChangeTextDocument((event) => {
      if (vscode.workspace.getConfiguration('fxl').get('diagnosticsOnChange', true)) {
        scheduleDiagnostics(event.document);
      }
    }),
    vscode.workspace.onDidCloseTextDocument((document) => {
      clearDiagnostics(document.uri);
      cancelPending(document.uri);
      latestRun.delete(document.uri.toString());
      disposeRunning(document.uri);
    })
  );

  for (const document of vscode.workspace.textDocuments) {
    if (document.languageId === 'fxl') {
      scheduleDiagnostics(document);
    }
  }

  context.subscriptions.push(
    vscode.commands.registerCommand('fxl.checkFile', () => {
      const editor = vscode.window.activeTextEditor;
      if (editor && editor.document.languageId === 'fxl') {
        runDiagnostics(editor.document);
      }
    })
  );
}

function deactivate() {
  for (const timer of pendingTimers.values()) {
    clearTimeout(timer);
  }
  for (const child of runningChecks.values()) {
    try { child.kill(); } catch (_) {}
  }
}

function scheduleDiagnostics(document) {
  if (document.languageId !== 'fxl' || document.uri.scheme !== 'file') {
    return;
  }

  cancelPending(document.uri);
  const debounce = Math.max(
    100,
    Math.min(2000, vscode.workspace.getConfiguration('fxl').get('diagnosticsDebounceMs', 350))
  );

  const timer = setTimeout(() => {
    pendingTimers.delete(document.uri.toString());
    runDiagnostics(document);
  }, debounce);

  pendingTimers.set(document.uri.toString(), timer);
}

function cancelPending(uri) {
  const key = uri.toString();
  const timer = pendingTimers.get(key);
  if (timer) {
    clearTimeout(timer);
    pendingTimers.delete(key);
  }
}

function clearDiagnostics(uri) {
  diagnosticCollection.delete(uri);
}

function disposeRunning(uri) {
  const key = uri.toString();
  const child = runningChecks.get(key);
  if (child) {
    try { child.kill(); } catch (_) {}
    runningChecks.delete(key);
  }
}

async function runDiagnostics(document) {
  if (document.languageId !== 'fxl' || document.uri.scheme !== 'file') {
    return;
  }

  const key = document.uri.toString();
  const runId = ++runCounter;
  latestRun.set(key, runId);
  disposeRunning(document.uri);

  const compiler = vscode.workspace.getConfiguration('fxl').get('compilerPath', 'fxlc') || 'fxlc';
  const versionAtStart = document.version;

  // Always compile from a temp copy to a temp output so checking never
  // writes generated files next to the user's source.
  let temp;
  try {
    temp = await createTempSource(document);
  } catch (error) {
    diagnosticCollection.set(document.uri, [
      makeFileDiagnostic(document, `Unable to prepare FXL check: ${error.message}`),
    ]);
    return;
  }

  const isCurrent = () =>
    latestRun.get(key) === runId && !document.isClosed && document.version === versionAtStart;

  const child = cp.spawn(compiler, ['compile', temp.sourcePath, '-o', temp.cppPath], {
    cwd: path.dirname(document.uri.fsPath),
    windowsHide: true,
    shell: false,
  });

  runningChecks.set(key, child);
  let stdout = '';
  let stderr = '';
  let finished = false;

  child.stdout.on('data', (data) => { stdout += data.toString(); });
  child.stderr.on('data', (data) => { stderr += data.toString(); });

  child.on('error', async (error) => {
    if (finished) return;
    finished = true;
    if (runningChecks.get(key) === child) runningChecks.delete(key);
    await cleanupTemp(temp);
    if (latestRun.get(key) !== runId || document.isClosed) return;

    const message = error.code === 'ENOENT'
      ? `FXL compiler '${compiler}' was not found. Add fxlc to PATH or set fxl.compilerPath.`
      : `Unable to run FXL compiler: ${error.message}`;

    diagnosticCollection.set(document.uri, [makeFileDiagnostic(document, message)]);
  });

  child.on('close', async (exitCode, signal) => {
    if (finished) return;
    finished = true;
    if (runningChecks.get(key) === child) runningChecks.delete(key);
    await cleanupTemp(temp);

    // A newer run replaced this one (child was killed) or the document changed: drop the result.
    if (!isCurrent() || signal) {
      return;
    }

    const output = `${stdout}\n${stderr}`.trim();
    const diagnostics = parseDiagnostics(output, document);

    if (exitCode === 0) {
      // Success clears old errors; keep only warnings the compiler may emit.
      const warnings = diagnostics.filter((d) => d.severity === vscode.DiagnosticSeverity.Warning);
      if (warnings.length) {
        diagnosticCollection.set(document.uri, warnings);
      } else {
        diagnosticCollection.delete(document.uri);
      }
      return;
    }

    if (!diagnostics.some((d) => d.severity === vscode.DiagnosticSeverity.Error)) {
      diagnostics.push(makeFileDiagnostic(
        document,
        output || `FXL compiler failed with exit code ${exitCode}.`
      ));
    }

    diagnosticCollection.set(document.uri, diagnostics);
  });
}

async function createTempSource(document) {
  const dir = path.dirname(document.uri.fsPath);
  const base = path.basename(document.uri.fsPath, '.fxl');
  const id = `${process.pid}_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
  const sourcePath = path.join(dir, `.${base}.vscode-${id}.fxl`);
  const cppPath = path.join(os.tmpdir(), `fxl-vscode-${id}.cpp`);
  await fs.promises.writeFile(sourcePath, document.getText(), 'utf8');
  return { sourcePath, cppPath };
}

async function cleanupTemp(temp) {
  if (!temp) return;
  await Promise.allSettled([
    fs.promises.unlink(temp.sourcePath),
    fs.promises.unlink(temp.cppPath),
  ]);
}

function parseDiagnostics(output, document) {
  const results = [];
  for (const rawLine of output.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line) continue;
    const parsed = parseDiagnosticLine(line, document);
    if (parsed) results.push(parsed);
  }
  return results;
}

function detectSeverity(text) {
  if (/\bwarning\b\s*(?:\[|:)/i.test(text)) return vscode.DiagnosticSeverity.Warning;
  return vscode.DiagnosticSeverity.Error;
}

function parseDiagnosticLine(text, document) {
  const isDiagnosticLine = /\b(?:error|warning)\b\s*(?:\[[A-Za-z0-9_]+\])?\s*:/i.test(text);
  if (!isDiagnosticLine) {
    return null;
  }

  const severity = detectSeverity(text);
  const codeMatch = text.match(/\[([A-Z][A-Z0-9_]+)\]/);
  const code = codeMatch ? codeMatch[1] : undefined;
  const message = extractMessage(text);

  // "... at line 5, column 9"
  const lc = text.match(/\bline\s+(\d+)\s*,\s*col(?:umn)?\s+(\d+)/i);
  if (lc) {
    return makeRangeDiagnostic(document, Number(lc[1]) - 1, Number(lc[2]) - 1, message, code, severity);
  }

  // "file.fxl:5:9: error ..."
  const colon = text.match(/:(\d+):(\d+)\b/);
  if (colon) {
    return makeRangeDiagnostic(document, Number(colon[1]) - 1, Number(colon[2]) - 1, message, code, severity);
  }

  // "... at line 5"
  const lineOnly = text.match(/\bline\s+(\d+)/i);
  if (lineOnly) {
    return makeRangeDiagnostic(document, Number(lineOnly[1]) - 1, 0, message, code, severity, true);
  }

  return makeFileDiagnostic(document, message, code, severity);
}

function extractMessage(text) {
  let message = text.trim();
  message = message.replace(/^.*?\b(?:error|warning)\b\s*(?:\[[A-Za-z0-9_]+\])?\s*:\s*/i, '');
  message = message.replace(/\s+at\s+line\s+\d+(?:\s*,\s*col(?:umn)?\s+\d+)?\s*$/i, '');
  return message || text.trim();
}

function makeRangeDiagnostic(document, line, column, message, code, severity, wholeLine = false) {
  const safeLine = Math.min(Math.max(0, line), Math.max(0, document.lineCount - 1));
  const lineText = document.lineAt(safeLine).text;
  const start = Math.min(Math.max(0, column), lineText.length);

  let end;
  if (wholeLine) {
    end = lineText.length;
  } else {
    // Underline the whole token at the reported column, or one character as fallback.
    const token = /^[A-Za-z0-9_#]+/.exec(lineText.slice(start));
    end = start + (token ? token[0].length : 1);
  }

  const range = new vscode.Range(safeLine, start, safeLine, Math.max(start + 1, Math.min(end, Math.max(lineText.length, start + 1))));
  const diagnostic = new vscode.Diagnostic(range, message, severity);
  diagnostic.source = 'fxlc';
  if (code) diagnostic.code = code;
  return diagnostic;
}

function makeFileDiagnostic(document, message, code, severity = vscode.DiagnosticSeverity.Error) {
  const range = new vscode.Range(0, 0, 0, Math.max(1, document.lineAt(0).text.length));
  const diagnostic = new vscode.Diagnostic(range, message, severity);
  diagnostic.source = 'fxlc';
  if (code) diagnostic.code = code;
  return diagnostic;
}

module.exports = {
  activate,
  deactivate,
};
