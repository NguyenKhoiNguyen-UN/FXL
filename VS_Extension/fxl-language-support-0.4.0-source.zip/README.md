# FXL Language Support

VS Code support for the FXL programming language.

## Features

- `.fxl` language detection
- Syntax highlighting (`import`, `#autoSet`, `#autoPick`, UI types, properties/methods, numbers, strings, percentages, hex colors)
- `//` line comments
- Diagnostics from the real `fxlc` compiler (Problems panel, editor squiggles, error codes, line/column mapping)
- FXL file icon (stylized `F`) shown for `.fxl` files alongside your current file icon theme

## Compiler

The extension runs `fxlc` from `PATH` by default. Override with:

```json
"fxl.compilerPath": "C:/path/to/fxlc.exe"
```

Checks run against a temporary copy of the file, so no generated output is written next to your source.

## File icons

The `.fxl` icon is contributed as a language icon, so it works with your existing file icon theme (Seti, Material, ...). No separate icon theme is needed.

## Extension logo

The marketplace logo is `images/fxl-extension.png` (placeholder — replace with the official PNG, at least 128x128).
